{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE QuasiQuotes       #-}
module Handler.BlogPost where

import Foundation
import Yesod.Core
import Yesod

getBlogPostR :: Handler Html
getBlogPostR = error ""

postBlogPostR :: Handler Html
postBlogPostR = error ""